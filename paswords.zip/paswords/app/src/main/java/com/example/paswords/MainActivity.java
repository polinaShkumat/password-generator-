package com.example.paswords;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button btn;
    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.button1);
        txt = (TextView)findViewById(R.id.text);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random rand = new Random();
                StringBuilder password = new StringBuilder();
                for (int i = 0; i < 10; i++) {
                    if (i % 2 == 0) {
                        // Generate a random letter
                        char letter = (char) (rand.nextInt(26) + 'a');
                        password.append(letter);
                    } else {
                        // Generate a random number
                        int number = rand.nextInt(10);
                        password.append(number);
                    }
                }
                txt.setText(password.toString());
            }
        });

    }
}